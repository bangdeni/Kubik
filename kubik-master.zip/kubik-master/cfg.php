<?php
$android_id = "6cbb1afxxxxxxxx";
$deviceCode = "8695450xxxxxxxx";
$device_ip  = "202.80xxxxxxxxx";
$token = "7d62FfijHQIvn0CnZLYJ8xxxxxxxxxxxxxxxxxx";
$tk = "ACGQr00V8VRJ14emgw7yUOQ5xxxxxxxxxxxxxxxxxx";
$uuid = "e1ac1cfe11f44xxxxxxxxxx";
$userid = "71xxxxxxx";
$sign = "0f72bab003xxxxxxxxxxxxx";

####################################################
#|note:
#| *untuk aktifitas nuyul multi akun
#|  gunakan andoid_id yang berbeda setiap akun
#|  gunakan devicecode (imei) yang berbeda setiap akun
#|  gunakan device_ip yang berbeda setiap akun
#| *untuk settingan lainya wajib sama 
#|  dengan data dari packet capture
#|
####################################################
#| cara mengaktifkan multi akun
#| duplikat data di atas dari anroid_id => sign
#| buat file baru dengan nama bebas terserah kamu
#| aktifkan skrip di bawah dngn menghapus tanda pagar
#| jika skrip di aktifkan maka hapus data di atas 
#|#####################################################
#| hapus pagar di bawah untuk mengaktifkan skrip

# include(readline("masukan config: "));